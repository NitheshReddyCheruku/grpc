﻿namespace gRPCService.models.ProductModels
{
    public class ProductModel
    {
        public int Id { get; set; }
        public string productName { get; set; }
        public string productCode { get; set; }
        public string Price { get; set; }
    }
}
