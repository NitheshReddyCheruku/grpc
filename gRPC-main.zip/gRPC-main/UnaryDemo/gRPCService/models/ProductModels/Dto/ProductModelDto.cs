﻿namespace gRPCService.models.ProductModels.Dto
{
    public class ProductModelDto
    {
        public string productName { get; set; }
        public string productCode { get; set; }
        public string Price { get; set; }

    }
}
